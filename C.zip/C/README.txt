compile the program using the makefile
1: 'make' in the terminal

run the instance of the server
2: ./server


NOTE: This program doesn't take any command line arguments yet, the PORT number in the program is '4003' for East Station